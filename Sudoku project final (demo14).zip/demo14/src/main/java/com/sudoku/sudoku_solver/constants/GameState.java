package com.sudoku.sudoku_solver.constants;

public enum GameState {
    COMPLETE,
    ACTIVE,
    NEW
}