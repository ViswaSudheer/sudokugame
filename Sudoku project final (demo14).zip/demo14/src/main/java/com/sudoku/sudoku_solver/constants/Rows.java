package com.sudoku.sudoku_solver.constants;

public enum Rows {
    TOP,
    MIDDLE,
    BOTTOM
}