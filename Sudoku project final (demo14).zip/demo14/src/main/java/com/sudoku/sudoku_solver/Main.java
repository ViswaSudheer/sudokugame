package com.sudoku.sudoku_solver;

public class Main {
    public static void main(String args[]){
        SudokuApplication.main(new String[]{});
    }
}